return {
    -- amongst your other plugins
    { 'akinsho/toggleterm.nvim', version = "*", config = true }
  }