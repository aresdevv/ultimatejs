-- This file contains the configuration for the vim-be-good plugin in Neovim.

return {
  -- Plugin: vim-be-good
  -- URL: https://github.com/ThePrimeagen/vim-be-good
  -- Description: A Neovim plugin designed to help you improve your Vim skills through various exercises and games.
  "ThePrimeagen/vim-be-good",
}
